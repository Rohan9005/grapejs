// TemplateEditor.tsx
import { useEffect, useRef, useState } from 'react';
import grapesjs from 'grapesjs';
import 'grapesjs/dist/css/grapes.min.css';
import presetWebpage from 'grapesjs-preset-webpage';
import Handlebars from 'handlebars';

type TemplateEditorProps = {
  initialHbs?: string;          // load an existing .hbs
  sampleData?: any;             // for preview
  variables?: string[];         // e.g. ['user.name','order.id']
  onExport?: (hbs: string) => void;
};

export default function TemplateEditor({
  initialHbs = '<div>{{title}}</div>',
  sampleData = { title: 'Hello' },
  variables = ['title'],
  onExport,
}: TemplateEditorProps) {
  const editorRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [editorReady, setEditorReady] = useState(false);

  // --- Handlebars <-> HTML adapter ---
  const PLACE_TAG = 'span';
  const HBS_ATTR = 'data-hbs';

  // turn {{user.name}} → <span data-hbs="{{user.name}}" class="hbs-token">{{user.name}}</span>
  const hbsToHtml = (hbs: string) =>
    hbs
      // block helpers first
      .replace(/{{#each\s+([^}]+)}}/g, `<${PLACE_TAG} ${HBS_ATTR}="{{#each $1}}" class="hbs-block-open">{{#each $1}}</${PLACE_TAG}>`)
      .replace(/{{#if\s+([^}]+)}}/g, `<${PLACE_TAG} ${HBS_ATTR}="{{#if $1}}" class="hbs-block-open">{{#if $1}}</${PLACE_TAG}>`)
      .replace(/{{\/(each|if)}}/g, `<${PLACE_TAG} ${HBS_ATTR}="{{/$1}}" class="hbs-block-close">{{/$1}}</${PLACE_TAG}>`)
      // inline
      .replace(/{{[^}]+}}/g, (m) => `<${PLACE_TAG} ${HBS_ATTR}="${m}" class="hbs-token">${m}</${PLACE_TAG}>`);

  // turn <span data-hbs="…"> back into raw {{…}}
  const htmlToHbs = (html: string) => {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    tmp.querySelectorAll<HTMLElement>(`${PLACE_TAG}[${HBS_ATTR}]`).forEach((el) => {
      const raw = el.getAttribute(HBS_ATTR) || '';
      el.replaceWith(document.createTextNode(raw));
    });
    return tmp.innerHTML;
  };

  useEffect(() => {
    if (!containerRef.current) return;

    const editor = grapesjs.init({
      container: containerRef.current,
      fromElement: false,
      height: '100%',
      storageManager: false, // you control save/load
      plugins: [presetWebpage],
      canvas: { styles: [], scripts: [] },
    });

    editorRef.current = editor;
    setEditorReady(true);

    // Load initial HBS
    const initialHtml = hbsToHtml(initialHbs);
    editor.setComponents(initialHtml);

    // Component type for our token placeholder (locks accidental edits)
    editor.DomComponents.addType('hbs-token', {
      isComponent: (el: HTMLElement) => el.tagName === PLACE_TAG.toUpperCase() && el.hasAttribute(HBS_ATTR),
      model: {
        defaults: {
          tagName: PLACE_TAG,
          droppable: false,
          draggable: true,
          copyable: true,
          traits: [
            { label: 'Handlebars', name: HBS_ATTR, type: 'text', changeProp: true },
          ],
          attributes: { class: 'hbs-token' },
        },
      },
    });

    // Interpret our placeholders as the above type
    editor.Parser.getConfig().compTypes?.unshift({
      id: 'hbs-token',
      isComponent: (el: HTMLElement) =>
        el.tagName === PLACE_TAG.toUpperCase() && el.hasAttribute(HBS_ATTR),
      model: { type: 'hbs-token' },
    });

    // Blocks panel: add tokens for variables
    variables.forEach((path) => {
      editor.BlockManager.add(`var-${path}`, {
        label: `{{${path}}}`,
        category: 'Variables',
        content: `<${PLACE_TAG} ${HBS_ATTR}="{{${path}}}" class="hbs-token">{{${path}}}</${PLACE_TAG}>`,
      });
    });

    // Blocks for #each and #if
    editor.BlockManager.add('hbs-each', {
      label: '{{#each}}',
      category: 'Logic',
      content:
        `<${PLACE_TAG} ${HBS_ATTR}="{{#each items}}" class="hbs-block-open">{{#each items}}</${PLACE_TAG}>` +
        '<div>Item content here</div>' +
        `<${PLACE_TAG} ${HBS_ATTR}="{{/each}}" class="hbs-block-close">{{/each}}</${PLACE_TAG}>`,
    });

    editor.BlockManager.add('hbs-if', {
      label: '{{#if}}',
      category: 'Logic',
      content:
        `<${PLACE_TAG} ${HBS_ATTR}="{{#if condition}}" class="hbs-block-open">{{#if condition}}</${PLACE_TAG}>` +
        '<div>Conditional content</div>' +
        `<${PLACE_TAG} ${HBS_ATTR}="{{/if}}" class="hbs-block-close">{{/if}}</${PLACE_TAG}>`,
    });

    return () => editor.destroy();
  }, []);

  const exportHbs = () => {
    const html = editorRef.current?.getHtml() || '';
    const css = editorRef.current?.getCss() || '';
    const merged = css ? `<style>${css}</style>${html}` : html;
    const hbs = htmlToHbs(merged);
    onExport?.(hbs);
  };

  const preview = () => {
    const html = editorRef.current?.getHtml() || '';
    const css = editorRef.current?.getCss() || '';
    const hbs = htmlToHbs(css ? `<style>${css}</style>${html}` : html);
    try {
      const tpl = Handlebars.compile(hbs);
      const compiled = tpl(sampleData);
      const w = window.open('', '_blank');
      if (w) w.document.write(compiled);
    } catch (e) {
      alert('Preview error: ' + (e as Error).message);
    }
  };

  return (
    <div className="grid grid-rows-[auto,1fr,auto] gap-2" style={{
        width: '100%', height: '80vh', gridRow:'auto', gap:'2'
    }}>
      <div className="flex gap-2">
        <button onClick={exportHbs} className="px-3 py-1 rounded bg-gray-200">Export .hbs</button>
        <button onClick={preview} className="px-3 py-1 rounded bg-gray-200">Preview</button>
      </div>
      <div ref={containerRef} className="border rounded" />
      {!editorReady && <div>Loading editor…</div>}
    </div>
  );
}
